<?php

namespace App\Controllers;
use App\Components\Membership;
use App\DataManager\TaskIntervalDataManager;
use App\Core\BaseController;
use App\Helpers\TimeHelper;

class Home extends BaseController{

    var $title = "Homepage";
    var $scripts = array("dashboard", "task");

    public function index(){
        $tasks = TaskIntervalDataManager::get_task_intervals_by_user_id();
        if(is_array($tasks)){
            $task_details = array();
            foreach($tasks as $task){
                $full_details = json_decode($task["task_intervals"]);
                $task_detail = new \stdClass;
                $task_detail->id = $task["id"];
                $task_detail->timer_set_name = $full_details->timer_set_name;
                $task_detail->total_time = TimeHelper::compute_time($full_details->duration);
                $task_detail->bg_color = $full_details->bg_color[0];
                $task_detail->text_color = $full_details->text_color[0];
                $task_detail->total_sets = sizeof($full_details->duration) . " sets";
                $task_details[] = $task_detail;
            }
            $this->model = $task_details;
        }   
    }               
}