<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Controllers;

use App\Core\BaseController;
use App\DataManager\TaskIntervalDataManager;
use App\Components\Membership;

class Task extends BaseController{
    
    var $scripts = array();
    var $layout = "none";
    public function index(){
        $this->model = new \stdClass;
        $this->model->id = 0;
        $this->model->data = new \stdClass;
        $this->model->data->timer_set_name = "";
        $this->model->data->task_name = array();
        if(!empty($this->id)){
            $timer_set = TaskIntervalDataManager::get_task_intervals_by_id($this->id);
            if(!empty($timer_set)){
                $this->model->id = $timer_set["id"];
                $this->model->data = json_decode($timer_set["task_intervals"]);
            } 
        }
    }
    
    public function details(){
        $json_data = array();
        if(!empty($this->id)){
            $timer_set = TaskIntervalDataManager::get_task_intervals_by_id($this->id);
            if(!empty($timer_set)){
                $data = json_decode($timer_set["task_intervals"]);
                if(is_array($data->task_name) && sizeof($data->task_name)){
                    $ctr = 0;
                    foreach($data->task_name as $task_name){
                        $details = new \stdClass;
                        $details->title = $task_name;
                        $details->time = $data->duration[$ctr];
                        $details->color = $data->bg_color[$ctr];
                        $details->t_color = $data->text_color[$ctr];
                        $json_data[] = $details;
                        $ctr++;
                    }
                }
            } 
        }
        $this->response_json(json_encode($json_data));
    }
    
    public function save(){
        
        $response = new \stdClass;
        $result = TaskIntervalDataManager::add_new_task_interval($_POST);
        if($result == null){
            $response->result = "success";
        }else{
            $response->result = "failed";
            $response->error_message = "Failed adding new Task/Interval";
        }
        //$this->response_json($response);
        $this->redirect(REAL_URL);
    }
}