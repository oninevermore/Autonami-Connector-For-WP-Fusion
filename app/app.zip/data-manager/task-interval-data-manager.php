<?php
namespace App\DataManager;
use App\Components\Database;
use App\Components\Membership;

class TaskIntervalDataManager{
    public static function add_new_task_interval($task){
        if($task["id"] > 0){
            $result = Database::update("tasks", [
                'user_id' => Membership::current_user()->id,
                'task_intervals' => json_encode($task),
                'date_created' => date("Y-m-d h:i:s")],
                ['id' => $task["id"]]
            );  
        }else{
            $result = Database::insert("tasks", [
                'user_id' => Membership::current_user()->id,
                'task_intervals' => json_encode($task),
                'date_created' => date("Y-m-d h:i:s")
            ]);  
        }
        return $result;
    }
    public static function get_task_intervals_by_user_id(){
        return Database::select("tasks", "*", array("user_id" => Membership::current_user()->id));
    }
    
    public static function get_task_intervals_by_id($id){
        return Database::get("tasks", "*", array("id" => $id));
    }
}