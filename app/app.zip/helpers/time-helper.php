<?php

namespace App\Helpers;

class TimeHelper {
    public static function compute_time($durations){
        if(is_array($durations)){
            $totalHours = 0;
            $totalMinutes = 0;
            $totalSeconds = 0;
            foreach ($durations as $duration) {
                $duration_split = explode(":", $duration);

                $totalHours += intval($duration_split[0]);
                $totalMinutes += intval($duration_split[1]);
                $totalSeconds += intval($duration_split[2]);
            }
            
            if($totalSeconds > 60){
                $remainingSeconds = floor($totalSeconds / 60);
                $totalSeconds = $totalSeconds - ($remainingSeconds * 60);
                $totalMinutes = $totalMinutes + $remainingSeconds;
            }
            
            if($totalMinutes > 60){
                $remainingMinutes = floor($totalMinutes / 60);
                $totalMinutes = $totalMinutes - ($remainingMinutes * 60);
                $totalHours = $totalHours + $remainingMinutes;
            }
            
            return ($totalHours > 9 ? "" : "0") . $totalHours . ":" . ($totalMinutes > 9 ? "" : "0") . $totalMinutes . ":" . ($totalSeconds > 9 ? "" : "0") . $totalSeconds;
        }
        return "00:00:00";
    }
}