<div id="timerGrp">
    <div class="row">
        <!--begin::Timer-->
        <div class="col-md-12" >
            <div class="timer p-7 ml-auto mr-auto">
                <h1 id="maintimer">00:00:00</h1>
            </div>
        </div>
        <!--end::Timer-->
    </div>
    <div class="row" >
        <div class="col-sm-4">
            <h2>Remaining</h2>
            <h3 id="remaining">00:00</h3>
        </div>
        <div class="col-sm-4 text-center">
            <h2>Queue</h2>
            <h3 id="queue">0/0</h3>
        </div>
        <div class="col-sm-4 text-right">
            <h2>Elapsed</h2>
            <h3 id="elapsed">00:00</h3>
        </div>
    </div>
</div>
    
<div class="scroll scroll-pull" data-scroll="true" data-wheel-propagation="true" id="items" style="height: 200px"></div>

<div class="modal fade" id="modalItems" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Saved Timer Sets</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i aria-hidden="true" class="ki ki-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="card-body pt-0">
                    <?php if(is_array($model)){?>
                        <?php foreach($model as $item){?>
                    <!--begin::Item-->
                    <div class="d-flex align-items-center mb-9 rounded p-5" style="background-color: <?=$item->bg_color?>">
                        <!--begin::Icon-->
                        <i class="icon-2x flaticon-stopwatch mr-5 ml-3" style="color: <?=$item->text_color?>"></i>
                        <!--end::Icon-->
                        <!--begin::Title-->
                        <div class="d-flex flex-column flex-grow-1 mr-2">
                            <a href="#" class="font-weight-bold text-hover-primary font-size-lg mb-1" style="color: <?=$item->text_color?>"><?=$item->timer_set_name?></a>
                            <span class="font-weight-bold" style="color: <?=$item->text_color?>; opacity: .6"><?=$item->total_sets?> | <?=$item->total_time?></span>
                        </div>
                        <!--end::Title-->
                        <!--begin::Lable-->
                        <span class="font-weight-bolder text-warning py-1 font-size-lg">
                            <button type="button" data-id="<?=$item->id?>" class="btn btn-icon btn-info btn-circle btn-sm mr-2 run"><i class="flaticon-time"></i></button>
                            <button type="button" data-id="<?=$item->id?>" class="btn btn-icon btn-success btn-circle btn-sm mr-2 edit-timer"><i class="flaticon-edit-1"></i></button>
                            <button type="button" class="btn btn-icon btn-danger btn-circle btn-sm mr-2"><i class="flaticon-cancel"></i></button>
                        </span>
                        <!--end::Lable-->
                    </div>
                    <!--end::Item-->
                        <?php }?>
                    <?php }?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light-primary font-weight-bold" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="btnNewTimer">
                    New Timer
                </button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="modalNewTimer" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">New Timer Set</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i aria-hidden="true" class="ki ki-close"></i>
                </button>
            </div>
            <div class="modal-body" id="tmrBody">
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light-primary font-weight-bold" data-dismiss="modal">Close</button>
                <button id="btnSaveTaskInterval" type="button" class="btn btn-primary font-weight-bold">Save changes</button>
            </div>
        </div>
    </div>
</div>