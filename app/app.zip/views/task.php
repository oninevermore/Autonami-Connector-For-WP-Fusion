<form id="frmTask" action="<?=REAL_URL?>/task/save" method="post">
    <input type="hidden" name="id" value="<?=$model->id?>"/>
    <div class="form-group mb-8">
        <div class="alert alert-custom alert-default" role="alert">
            <div class="alert-icon"><i class="flaticon-info text-primary"></i></div>
            <div class="alert-text">
                Enter Timer details below.
            </div>
        </div>
    </div>
    
    <div class="form-group row">
        <div class="col-lg-12">
            <label>Timer Set Name:</label>
            <input class="form-control" type="text" value="<?=$model->data->timer_set_name?>" placeholder="Timer Set Name" name="timer_set_name"/>
        </div>   
    </div>
    
    <?php if(is_array($model->data->task_name) && sizeof($model->data->task_name)){ ?>
        <?php $ctr = 0;?>
            <?php foreach($model->data->task_name as $task_name){?>
                <div class="card card-custom bg-success mb-8">
                    <div class="card-header border-0">
                        <div class="card-title">
                            <span class="card-icon">
                                <i class="flaticon2-chat-1 text-white"></i>
                            </span>
                            <h3 class="card-label text-white">
                                Task/Interval
                            </h3>
                        </div>
                        <div class="card-toolbar">
                            <a href="#" class="remove-int-task btn btn-sm btn-danger font-weight-bold <?=($ctr == 0 ? "disabled" : "")?>">
                                <i class="flaticon-cancel"></i> Remove
                            </a>
                        </div>
                    </div>
                    <div class="separator separator-solid separator-white opacity-20"></div>
                    <div class="card-body text-white">


                        <div class="form-group row">
                            <div class="col-lg-6">
                                <label>Task/Interval Name</label>
                                <input class="form-control" type="text" value="<?=$task_name ?>" placeholder="Task/Interval Name" name="task_name[]"/>
                            </div>
                            <div class="col-lg-6">
                                <label>Duration</label>
                                <div class="input-group timepicker">
                                    <input class="form-control duration" readonly placeholder="Select time" value="<?=$model->data->duration[$ctr]?>" type="text" name="duration[]"/>
                                    <div class="input-group-append">
                                        <span class="input-group-text">
                                            <i class="la la-clock-o"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-lg-6">
                                <label>BG Color</label>
                                <input class="form-control" type="color" value="<?=$model->data->bg_color[$ctr]?>" name="bg_color[]"/>
                            </div>
                            <div class="col-lg-6">
                                <label>Text Color</label>
                                <input class="form-control" type="color" value="<?=$model->data->text_color[$ctr]?>" name="text_color[]"/>
                            </div>
                        </div>
                    </div>
                </div>
            <?php $ctr++;?>
        <?php }?>
    <?php }else{?>
        <div class="card card-custom bg-success mb-8">
            <div class="card-header border-0">
                <div class="card-title">
                    <span class="card-icon">
                        <i class="flaticon2-chat-1 text-white"></i>
                    </span>
                    <h3 class="card-label text-white">
                        Task/Interval
                    </h3>
                </div>
                <div class="card-toolbar">
                    <a href="#" class="remove-int-task btn btn-sm btn-danger font-weight-bold disabled">
                        <i class="flaticon-cancel"></i> Remove
                    </a>
                </div>
            </div>
            <div class="separator separator-solid separator-white opacity-20"></div>
            <div class="card-body text-white">


                <div class="form-group row">
                    <div class="col-lg-6">
                        <label>Task/Interval Name</label>
                        <input class="form-control" type="text" value="" placeholder="Task/Interval Name" name="task_name[]"/>
                    </div>
                    <div class="col-lg-6">
                        <label>Duration</label>
                        <div class="input-group timepicker">
                            <input class="form-control duration" readonly placeholder="Select time" value="00:01:00" type="text" name="duration[]"/>
                            <div class="input-group-append">
                                <span class="input-group-text">
                                    <i class="la la-clock-o"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-lg-6">
                        <label>BG Color</label>
                        <input class="form-control" type="color" value="#FFFFFF" name="bg_color[]"/>
                    </div>
                    <div class="col-lg-6">
                        <label>Text Color</label>
                        <input class="form-control" type="color" value="#000000" name="text_color[]"/>
                    </div>
                </div>
            </div>
        </div>
    <?php }?>
    <a href="#" id="addTaskInterval" class="btn btn-sm btn-success font-weight-bold float-right">
        <i class="flaticon2-plus"></i> Add Task/Interval
    </a>
    
            
</form>