<div style="font-family: 'Arial'">
    <p>Hi, <b><?=$model->first_name?></b></p>
    <p>&nbsp;</p>
    <p><b><?=$model->sender?></b> has shared a timer to you. Please click button below to accept invitation.</b>
    <p><a href="<?=$model->url?>" target="_blank" style="border: 1px solid transparent;padding: .65rem 1rem; background-color: green;color: white;border-radius: .42rem; font-size: 1rem;line-height: 1.5; text-decoration: none">Accept</a></p>    
    <p>&nbsp;</p>
    <p>EVERMORE TIMER TEAM</p>
</div>
