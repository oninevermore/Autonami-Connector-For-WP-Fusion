/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


var initTimePicker = function(obj){
    obj.timepicker({
        minuteStep: 1,
        defaultTime: '',
        showSeconds: true,
        showMeridian: false,
        snapToStep: true
    });
}

var bindAddTaskInterval = function(){
    $("#addTaskInterval").click(function () {
        var clone = $(this).siblings(".card:first").clone();
        $(".remove-int-task", clone).removeClass("disabled").click(function () {
            $(this).parents(".card").remove();
        });
        initTimePicker($(".duration", clone));
        $(this).before(clone);
    });
};

var editTaskInterval = function(){
    $(".edit-timer").click(function () {
        var id = $(this).data("id");
        $.get(real_url + "/task", {id:id}, function (result) {
            $("#tmrBody").html(result);
            initTimePicker($(".duration"));
            $("#modalNewTimer").modal("show");
            
            $(".remove-int-task").click(function () {
                $(this).parents(".card").remove();
            });
            bindAddTaskInterval();
        });
    });
}
        
$("document").ready(
    function () {
        $("#btnNewTimer").click(function () {
            $.get(real_url + "/task", function (result) {
                $("#tmrBody").html(result);
                initTimePicker($(".duration"));
                $("#modalNewTimer").modal("show");
                bindAddTaskInterval();
            });
        });
        
        editTaskInterval();
        $("#btnSaveTaskInterval").click(function () {
            $("#frmTask").submit();
        });
    }
);


