/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var queues = [
    {
        "title":"Record clients list",
        "time": "0:0:16",
        "color":"#007bff",
    },
    {
        "title":"Compute Salary",
        "time": "0:0:20",
        "color":"#20c997",
    },
    {
        "title":"Clean table",
        "time": "0:1:10",
        "color":"yellow",
    }
    ,
    {
        "title":"Coffee break",
        "time": "0:0:10",
        "color":"orange",
    }
];
var nextQueueIndex = 0;
//var currentQueue = queues[currentQueueIndex];
//var currentQueueSplit = currentQueue.split(":");

var hours = 0;
var minutes = 0;
var seconds = 0;

var totalHours = 0;
var totalMinutes = 0;
var totalSeconds = 0;

var elapsedHours = 0;
var elapsedMinutes = 0;
var elapsedSeconds = 0;

var setQueueItems = function(){
    var html = "";
    if(queues.length > 0){
        for (i = 0; i < queues.length; i++) {
            html += '<div class="col-md-12" id="task-item-' + i + '">' +
                        '<div class="alert text-center" style="background-color:' + queues[i].color + '" role="alert">' +
                            '<h1>' + queues[i].title + '</h1>' +
                        '</div>' +
                    '</div>'
        }
    }
    $("#items").html(html);
}

var setQueueTimer = function(){
    var currentQueue = queues[nextQueueIndex].time;
    $("#task-item-" + (nextQueueIndex - 1)).hide();
    $("#queue").html((nextQueueIndex + 1) + "/" + (queues.length));
    $("body").css("background-color", queues[nextQueueIndex].color);
    var currentQueueSplit = currentQueue.split(":");

    hours = parseInt(currentQueueSplit[0]);
    minutes = parseInt(currentQueueSplit[1]);
    seconds = parseInt(currentQueueSplit[2]);
    nextQueueIndex = nextQueueIndex + 1;
    runTimer();
};

var runTimer = function(){
    var timer = setInterval(function () {
        $("#maintimer").html((hours > 9 ? "" : "0") + hours + ":" + (minutes > 9 ? "" : "0") + minutes + ":" + (seconds > 9 ? "" : "0") + seconds);
        $("#remaining").html((totalHours > 9 ? "" : "0") + totalHours + ":" + (totalMinutes > 9 ? "" : "0") + totalMinutes + ":" + (totalSeconds > 9 ? "" : "0") + totalSeconds);
        $("#elapsed").html((elapsedHours > 9 ? "" : "0") + elapsedHours + ":" + (elapsedMinutes > 9 ? "" : "0") + elapsedMinutes + ":" + (elapsedSeconds > 9 ? "" : "0") + elapsedSeconds);
        
        if(seconds > 0){
            seconds = seconds - 1;
        }else{
            if(minutes > 0){
                minutes = minutes - 1;
                seconds = 59;
            }else{
                if(hours > 0){
                    hours = hours - 1;
                    minutes = minutes - 1;
                    seconds = 59;
                }else{
                    clearInterval(timer);
                    if(queues.length > nextQueueIndex){
                        setQueueTimer();
                        return;
                    }else{
                        //alert("done");
                    }
                }
            }
        }
        computeRemaining();
        computeElapsed();

    }, 1000);

};

var computeElapsed = function(){
    if(elapsedSeconds < 60){
        elapsedSeconds = elapsedSeconds + 1;
    }else{
        if(elapsedMinutes < 60){
            elapsedMinutes = elapsedMinutes + 1;
            elapsedSeconds = 0;
        }else{
            if(elapsedHours < 60){
                elapsedHours = elapsedHours + 1;
                elapsedMinutes = elapsedMinutes + 1;
                elapsedSeconds = 0;
            }else{

            }
        }
    }
}

var computeRemaining = function(){
    if(totalSeconds > 0){
        totalSeconds = totalSeconds - 1;
    }else{
        if(totalMinutes > 0){
            totalMinutes = totalMinutes - 1;
            totalSeconds = 59;
        }else{
            if(totalHours > 0){
                totalHours = totalHours - 1;
                totalMinutes = totalMinutes - 1;
                totalSeconds = 59;
            }else{

            }
        }
    }
}

var computeTotalHours = function(){
    if(queues.length > 0){
        for (i = 0; i < queues.length; i++) {
            var queue = queues[i].time;
            var queueSplit = queue.split(":");

            totalHours = totalHours + parseInt(queueSplit[0]);
            totalMinutes += parseInt(queueSplit[1]);
            totalSeconds += parseInt(queueSplit[2]);
        }
        
        if(totalSeconds > 60){
            var remainingSeconds = Math.floor(totalSeconds / 60);
            totalSeconds = totalSeconds - (remainingSeconds * 60);
            totalMinutes = totalMinutes + remainingSeconds;
        }
        if(totalMinutes > 60){
            var remainingMinutes = Math.floor(totalMinutes / 60);
            totalMinutes = totalMinutes - (remainingMinutes * 60);
            totalHours = totalHours + remainingMinutes;
        }
        
        $("#remaining").html((totalHours > 9 ? "" : "0") + totalHours + ":" + (totalMinutes > 9 ? "" : "0") + totalMinutes + ":" + (totalSeconds > 9 ? "" : "0") + totalSeconds);
    }
};

setQueueItems();
setQueueTimer();
computeTotalHours();

