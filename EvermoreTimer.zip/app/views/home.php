
<div class="row">
    <!--begin::Timer-->
    <div class="col-md-12" >
        <div class="timer p-7 ml-auto mr-auto">
            <h1 id="maintimer">00:00:00</h1>
        </div>
    </div>
    <!--end::Timer-->
</div>
<div class="row" >
    <div class="col-sm-4">
        <h2>Remaining</h2>
        <h3 id="remaining">00:00</h3>
    </div>
    <div class="col-sm-4 text-center">
        <h2>Queue</h2>
        <h3 id="queue">0/0</h3>
    </div>
    <div class="col-sm-4 text-right">
        <h2>Elapsed</h2>
        <h3 id="elapsed">00:00</h3>
    </div>
</div>
<div class="row" id="items"></div>