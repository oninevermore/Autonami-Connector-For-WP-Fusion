<?php

namespace App\Controllers;
use App\Components\Membership;

use \App\Core\BaseController;

class Home extends BaseController{

    var $title = "Homepage";
    var $scripts = array("dashboard");

    public function index(){
        $this->model = Membership::current_user();
    }
}